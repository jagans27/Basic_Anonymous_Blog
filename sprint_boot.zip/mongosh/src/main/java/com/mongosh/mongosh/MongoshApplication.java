package com.mongosh.mongosh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoshApplication {

	public static void main(String[] args) {

		SpringApplication.run(MongoshApplication.class, args);

	}

}
