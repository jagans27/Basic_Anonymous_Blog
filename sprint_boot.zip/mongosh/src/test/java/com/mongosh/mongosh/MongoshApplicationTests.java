package com.mongosh.mongosh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoshApplicationTests {

	@Test
	void contextLoads() {
	}

}
